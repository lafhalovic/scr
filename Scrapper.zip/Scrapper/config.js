window.__CONFIG__ = {
  // url must NOT end with a slash
  VITE_CORS_PROXY_URL: "https://movies.haitam1lafhal.workers.dev/",
  VITE_TMDB_READ_API_KEY: "de899d9047df6d5bec6a6cc81ebfac5a"
};
